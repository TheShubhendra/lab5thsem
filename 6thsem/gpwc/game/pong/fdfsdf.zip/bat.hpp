#pragma once
#include<SFML/Graphics.hpp>

class Bat{
  public:
   sf::RectangleShape sprite = sf::RectangleShape(sf::Vector2f(50,10));

   Bat(sf::Vector2f, sf::Vector2f);

};