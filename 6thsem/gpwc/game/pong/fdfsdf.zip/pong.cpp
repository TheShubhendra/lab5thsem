#include <SFML/Graphics.hpp>
#include "bat.hpp"

#define WIDTH 1920
#define HEIGHT 1080

using namespace sf;
int main(){
    VideoMode vm(WIDTH, HEIGHT);
    RenderWindow window(vm, "Pong!");
    Bat bat = Bat(Vector2f(0, HEIGHT-10));
    Event event;
    while(window.isOpen()){
        window.pollEvent(event);
        if (Keyboard::isKeyPressed(Keyboard::Escape)){
            break;
        }

        // Handle input




        window.clear();
        // Draw here
        window.draw(bat.sprite);










        window.display();


    }

    return 0;
}