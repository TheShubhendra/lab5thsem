#include "bat.hpp"

Bat::Bat(sf::Vector2f intialPosition , sf::Vector2f){
    sprite.setPosition(intialPosition);
    sprite.setSize(size);
    
}

